"use client";
import { useState } from "react";
import {
  MessageSquarePlus,
  Trash2,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Clock,
  Link2,
} from "lucide-react";
import ThemeToggle from "./ThemeToggle";

const OFFICIAL_LINKS = [
  { label: "NUST Main Website", url: "https://nust.edu.pk" },
  { label: "UG Admissions Portal", url: "https://ugadmissions.nust.edu.pk" },
  { label: "Fee Structure", url: "https://nust.edu.pk/admissions/fee-structure/undergraduate-financial-matters/" },
  { label: "Scholarships", url: "https://nust.edu.pk/admissions/scholarships/" },
  { label: "UG Programs", url: "https://nust.edu.pk/admissions/undergraduates/list-of-ug-programmes-and-institutions" },
  { label: "FAQs", url: "https://nust.edu.pk/faqs/" },
];

export default function Sidebar({
  conversations,
  activeId,
  onSelect,
  onNew,
  onDelete,
}) {
  const [collapsed, setCollapsed] = useState(false);

  if (collapsed) {
    return (
      <div
        className="flex flex-col items-center py-4 px-1 gap-3"
        style={{
          background: "var(--bg-sidebar)",
          borderRight: "1px solid var(--border-light)",
          width: "52px",
        }}
      >
        <button
          onClick={() => setCollapsed(false)}
          className="p-2 rounded-xl transition-all hover:scale-110"
          style={{ color: "var(--text-tertiary)", background: "var(--bg-tertiary)" }}
          title="Expand sidebar"
        >
          <ChevronRight size={16} />
        </button>
        <button
          onClick={onNew}
          className="p-2 rounded-xl transition-all hover:scale-110"
          style={{ color: "var(--text-on-primary)", background: "var(--nust-primary)" }}
          title="New chat"
        >
          <MessageSquarePlus size={16} />
        </button>
        <div className="mt-auto">
          <ThemeToggle />
        </div>
      </div>
    );
  }

  return (
    <div
      className="flex flex-col h-full glass-panel border-r-0 border-y-0"
      style={{
        width: "280px",
        minWidth: "280px",
        borderRight: "1px solid var(--glass-border)",
        boxShadow: "10px 0 30px rgba(0,0,0,0.05)"
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4"
        style={{ borderBottom: "1px solid var(--glass-border)" }}
      >
        <span
          className="text-lg font-black tracking-tight drop-shadow-sm"
          style={{ color: "var(--nust-primary)" }}
        >
          NUST<span style={{ color: "var(--nust-accent)"}}>Bot</span>
        </span>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <button
            onClick={() => setCollapsed(true)}
            className="p-2 rounded-xl transition-all hover:bg-[var(--glass-bg-hover)]"
            style={{ color: "var(--text-tertiary)" }}
            title="Collapse"
          >
            <ChevronLeft size={18} strokeWidth={2.5} />
          </button>
        </div>
      </div>

      {/* New Chat Button */}
      <div className="px-4 py-4">
        <button
          onClick={onNew}
          className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-sm font-bold transition-all hover:scale-[1.03] shadow-lg hover:shadow-xl"
          style={{
            background: "linear-gradient(135deg, var(--nust-primary) 0%, var(--nust-secondary) 100%)",
            color: "#FFFFFF",
            border: "1px solid rgba(255,255,255,0.2)"
          }}
          id="new-chat-button"
        >
          <MessageSquarePlus size={18} />
          <span>New Conversation</span>
        </button>
      </div>

      {/* Recent Chats */}
      <div className="flex-1 overflow-y-auto px-3 py-1">
        <div className="flex items-center gap-1.5 px-2 py-1.5 mb-1">
          <Clock size={12} style={{ color: "var(--text-tertiary)" }} />
          <span
            className="text-xs font-medium uppercase tracking-wider"
            style={{ color: "var(--text-tertiary)" }}
          >
            Recent Chats
          </span>
        </div>

        {conversations.length === 0 ? (
          <p
            className="text-xs px-2 py-4 text-center"
            style={{ color: "var(--text-tertiary)" }}
          >
            No conversations yet. Start a new chat!
          </p>
        ) : (
          conversations.map((convo) => (
            <div
              key={convo.id}
              className="group flex items-center gap-2 px-3 py-2 rounded-xl mb-0.5 cursor-pointer transition-all"
              style={{
                background:
                  activeId === convo.id
                    ? "var(--bg-hover)"
                    : "transparent",
                color: "var(--text-primary)",
              }}
              onClick={() => onSelect(convo.id)}
            >
              <span className="flex-1 truncate text-xs">{convo.title}</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(convo.id);
                }}
                className="opacity-0 group-hover:opacity-100 p-1 rounded transition-all"
                style={{ color: "var(--text-tertiary)" }}
                title="Delete"
              >
                <Trash2 size={12} />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Official Links */}
      <div
        className="px-3 py-3 overflow-y-auto"
        style={{
          borderTop: "1px solid var(--border-light)",
          maxHeight: "200px",
        }}
      >
        <div className="flex items-center gap-1.5 px-2 py-1.5 mb-1">
          <Link2 size={12} style={{ color: "var(--text-tertiary)" }} />
          <span
            className="text-xs font-medium uppercase tracking-wider"
            style={{ color: "var(--text-tertiary)" }}
          >
            Official Links
          </span>
        </div>
        {OFFICIAL_LINKS.map((link, i) => (
          <a
            key={i}
            href={link.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs transition-all hover:scale-[1.02]"
            style={{ color: "var(--text-link)" }}
          >
            <ExternalLink size={11} className="flex-shrink-0 opacity-50" />
            <span className="truncate">{link.label}</span>
          </a>
        ))}
      </div>
    </div>
  );
}
