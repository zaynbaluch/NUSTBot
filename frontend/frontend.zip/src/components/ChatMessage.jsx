"use client";
import { Bot, User } from "lucide-react";
import ConfidenceBadge from "./ConfidenceBadge";
import SourceTooltip from "./SourceTooltip";

export default function ChatMessage({ message, isLatest }) {
  const isUser = message.role === "user";
  const isStreaming = isLatest && message.role === "assistant" && !message.content;

  return (
    <div
      className={`flex gap-4 animate-fade-in ${isUser ? "flex-row-reverse" : "flex-row"}`}
      style={{ maxWidth: "88%" , marginLeft: isUser ? "auto" : "0" }}
    >
      {/* Avatar */}
      <div
        className="flex-shrink-0 w-10 h-10 rounded-2xl flex items-center justify-center mt-1 shadow-md border"
        style={{
          background: isUser ? "var(--msg-user-bg)" : "var(--glass-bg)",
          color: isUser ? "#FFFFFF" : "var(--nust-primary)",
          borderColor: isUser ? "transparent" : "var(--glass-border)",
          backdropFilter: "blur(10px)"
        }}
      >
        {isUser ? <User size={20} strokeWidth={2} /> : <Bot size={22} strokeWidth={2} />}
      </div>

      {/* Message Bubble */}
      <div className="flex flex-col gap-2 min-w-0">
        <div
          className="px-5 py-3.5 text-[0.95rem] leading-[1.6] shadow-sm relative z-10"
          style={{
            background: isUser ? "var(--msg-user-bg)" : "var(--msg-bot-bg)",
            color: isUser ? "#FFFFFF" : "var(--text-primary)",
            borderBottomRightRadius: isUser ? "8px" : "24px",
            borderBottomLeftRadius: isUser ? "24px" : "8px",
            borderTopLeftRadius: "24px",
            borderTopRightRadius: "24px",
            backdropFilter: "blur(12px)",
            border: isUser ? "none" : "1px solid var(--glass-border)",
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
          }}
        >
          {isStreaming ? (
            <div className="typing-indicator flex items-center gap-1.5 py-2">
              <span />
              <span />
              <span />
            </div>
          ) : (
            message.content
          )}
        </div>

        {/* Sources & Confidence (bot messages only) */}
        {!isUser && message.sources && message.sources.length > 0 && (
          <div className="flex flex-wrap items-center gap-2.5 px-2 mt-0.5 animate-fade-in">
            <span className="text-xs font-semibold tracking-wider uppercase opacity-70" style={{ color: "var(--text-tertiary)" }}>
              Sources
            </span>
            {message.sources.map((src, i) => (
              <SourceTooltip key={i} source={src} />
            ))}
            {message.confidence !== null && (
              <ConfidenceBadge score={message.confidence} />
            )}
          </div>
        )}
      </div>
    </div>
  );
}
