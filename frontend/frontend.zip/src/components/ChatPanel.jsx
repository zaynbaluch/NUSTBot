"use client";
import { useRef, useEffect } from "react";
import { Sparkles, GraduationCap, DollarSign, CalendarDays, HelpCircle } from "lucide-react";
import ChatMessage from "./ChatMessage";

const QUICK_STARTERS = [
  { label: "How to apply?", icon: GraduationCap, query: "How can I apply for admission at NUST?" },
  { label: "Fee structure", icon: DollarSign, query: "What is the fee structure for undergraduate programs at NUST?" },
  { label: "Scholarships", icon: Sparkles, query: "Does NUST offer scholarships or financial aid?" },
  { label: "Entry test info", icon: CalendarDays, query: "What is the format and syllabus of the NUST Entry Test (NET)?" },
  { label: "CS admission", icon: HelpCircle, query: "What is the eligibility criteria for Computer Science at NUST?" },
];

export default function ChatPanel({ messages, isLoading, status, onSend }) {
  const bottomRef = useRef(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const isEmpty = messages.length === 0;

  return (
    <div
      className="flex-1 overflow-y-auto px-4 py-6 md:px-8 relative z-10"
      style={{ background: "transparent" }}
    >
      {isEmpty ? (
        /* ── Welcome Screen (Premium Redesign) ── */
        <div className="flex flex-col items-center justify-center h-full animate-fade-in relative">
          
          <div className="relative mb-8 mt-[-5vh]">
            <div className="absolute inset-0 bg-[var(--nust-primary)] blur-3xl opacity-20 rounded-full scale-150 animate-pulse" />
            <div
              className="w-20 h-20 rounded-3xl flex items-center justify-center relative z-10 glass-panel border border-[var(--glass-border)] shadow-xl"
              style={{ color: "var(--nust-primary)", background: "var(--glass-bg)" }}
            >
              <GraduationCap size={40} strokeWidth={1.5} />
            </div>
          </div>

          <h1
            className="text-3xl font-extrabold mb-3 tracking-tight drop-shadow-sm"
            style={{ color: "var(--text-primary)" }}
          >
            Welcome to NUST<span style={{ color: "var(--nust-accent)"}}>Bot</span>
          </h1>
          <p
            className="text-base mb-10 text-center max-w-lg leading-relaxed"
            style={{ color: "var(--text-secondary)" }}
          >
            Your state-of-the-art AI admissions assistant. Ask me anything about NUST
            programs, fees, scholarships, and the complete application process.
          </p>

          {/* Quick Starters (Glass Cards) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-2xl px-4">
            {QUICK_STARTERS.map((item, i) => (
              <button
                key={i}
                onClick={() => onSend(item.query)}
                className="glass-panel flex items-center gap-4 px-5 py-4 text-left transition-all hover:-translate-y-1 hover:shadow-xl rounded-2xl group"
                style={{ color: "var(--text-primary)" }}
                id={`quick-starter-${i}`}
              >
                <div className="p-2 rounded-xl bg-[var(--nust-primary)] text-white group-hover:scale-110 transition-transform shadow-md">
                   <item.icon size={20} strokeWidth={2} />
                </div>
                <span className="font-semibold text-sm group-hover:text-[var(--nust-primary)] transition-colors">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        /* ── Messages ── */
        <div className="flex flex-col gap-6 max-w-3xl mx-auto pb-4">
          {/* Status Bar */}
          {status && (
            <div
              className="flex items-center gap-3 px-5 py-2.5 rounded-full text-xs font-semibold self-center animate-fade-in glass-pill shadow-lg"
              style={{
                color: "var(--nust-primary)",
              }}
            >
              <div className="w-2.5 h-2.5 rounded-full bg-[var(--nust-accent)] animate-ping" />
              {status === "thinking" && "Expanding query architecture..."}
              {status === "searching" && "Scanning knowledge base..."}
              {status === "answering" && "Generating intelligent response..."}
            </div>
          )}

          {messages.map((msg, i) => (
            <ChatMessage
              key={i}
              message={msg}
              isLatest={i === messages.length - 1 && isLoading}
            />
          ))}
          <div ref={bottomRef} />
        </div>
      )}
    </div>
  );
}
