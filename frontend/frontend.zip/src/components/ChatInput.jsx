"use client";
import { useState, useEffect, useRef } from "react";
import { Send, Mic, MicOff, Square } from "lucide-react";

export default function ChatInput({
  onSend,
  isLoading,
  onStop,
  speechToText,
}) {
  const [input, setInput] = useState("");
  const inputRef = useRef(null);

  // Sync speech transcript to input
  useEffect(() => {
    if (speechToText?.transcript) {
      setInput(speechToText.transcript);
    }
  }, [speechToText?.transcript]);

  const handleSubmit = (e) => {
    e?.preventDefault();
    if (!input.trim() || isLoading) return;
    onSend(input.trim());
    setInput("");
  };

  const handleKeyDown = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="px-2 md:px-6 py-2 pb-4">
      <div className="max-w-4xl mx-auto relative group">
        
        {/* Glow behind input */}
        <div className="absolute -inset-1 bg-gradient-to-r from-[var(--nust-primary)] to-[var(--nust-accent)] rounded-[32px] blur opacity-20 group-hover:opacity-40 transition duration-500" />
        
        <form
          onSubmit={handleSubmit}
          className="relative flex items-center gap-3 px-3 py-2.5 rounded-[32px] transition-all glass-pill bg-[var(--glass-bg)]"
        >
          {/* Microphone */}
          {speechToText?.isSupported && (
            <button
              type="button"
              onClick={speechToText.toggleListening}
              className="p-3 rounded-full transition-all hover:scale-110 flex-shrink-0"
              style={{
                color: speechToText.isListening ? "#ef4444" : "var(--text-tertiary)",
                background: speechToText.isListening ? "rgba(239, 68, 68, 0.15)" : "transparent",
              }}
              title={speechToText.isListening ? "Stop listening" : "Speak"}
              id="mic-button"
            >
              {speechToText.isListening ? <MicOff size={20} className="animate-pulse" /> : <Mic size={20} />}
            </button>
          )}

          {/* Text Input */}
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder={
              speechToText?.isListening
                ? "Listening..."
                : "Ask about NUST admissions, programs, fees..."
            }
            className="flex-1 bg-transparent outline-none text-base px-2 placeholder-[var(--text-tertiary)]"
            style={{ color: "var(--text-primary)" }}
            disabled={isLoading}
            id="chat-input"
          />

          {/* Send / Stop */}
          {isLoading ? (
            <button
              type="button"
              onClick={onStop}
              className="p-3 mr-1 rounded-full transition-all hover:scale-110 flex-shrink-0 shadow-md"
              style={{ color: "#ef4444", background: "rgba(239, 68, 68, 0.15)" }}
              title="Stop generating"
              id="stop-button"
            >
              <Square size={20} fill="currentColor" />
            </button>
          ) : (
            <button
              type="submit"
              disabled={!input.trim()}
              className="p-3 mr-1 rounded-full transition-all hover:scale-110 flex-shrink-0 disabled:opacity-40 disabled:hover:scale-100 shadow-lg"
              style={{
                background: input.trim()
                  ? "var(--msg-user-bg)"
                  : "var(--bg-tertiary)",
                color: input.trim()
                  ? "#FFFFFF"
                  : "var(--text-tertiary)",
              }}
              title="Send message"
              id="send-button"
            >
              <Send size={20} className={input.trim() ? "translate-x-0.5" : ""} />
            </button>
          )}
        </form>
      </div>

      <p
        className="text-center text-[11px] mt-4 font-medium"
        style={{ color: "var(--text-tertiary)" }}
      >
        NUSTBot may occasionally provide inaccurate info. Verify important details on{" "}
        <a
          href="https://nust.edu.pk"
          target="_blank"
          rel="noopener noreferrer"
          className="hover:underline transition-all"
          style={{ color: "var(--nust-primary)" }}
        >
          nust.edu.pk
        </a>
      </p>
    </div>
  );
}
