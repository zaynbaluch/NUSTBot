"use client";
import { useMemo } from "react";

export default function RobotMascot({ state = "idle" }) {
  // Define state-specific properties to drastically modify the aesthetic of the robot
  const config = useMemo(() => {
    switch (state) {
      case "thinking":
        return {
          label: "Analyzing NUST Data...",
          glowColor: "#F59E0B", // Amber
          eyeContent: (
            <g>
              <circle cx="85" cy="115" r="8" fill="#F59E0B" className="animate-spin" style={{ transformOrigin: '85px 115px' }} />
              <circle cx="155" cy="115" r="8" fill="#F59E0B" className="animate-spin" style={{ transformOrigin: '155px 115px' }} />
              <rect x="70" y="113" width="100" height="4" fill="#F59E0B" opacity="0.5" />
            </g>
          ),
          mouthContent: <rect x="110" y="145" width="20" height="4" rx="2" fill="#F59E0B" />,
        };
      case "happy":
        return {
          label: "Found your answer! ✨",
          glowColor: "#10B981", // Emerald
          eyeContent: (
            <g fill="#10B981">
              <path d="M75 120 Q85 105 95 120" stroke="#10B981" strokeWidth="6" strokeLinecap="round" fill="none" />
              <path d="M145 120 Q155 105 165 120" stroke="#10B981" strokeWidth="6" strokeLinecap="round" fill="none" />
            </g>
          ),
          mouthContent: <path d="M100 145 Q120 160 140 145" stroke="#10B981" strokeWidth="6" strokeLinecap="round" fill="none" />,
        };
      case "confused":
        return {
          label: "Hmm, that's outside my scope 🤔",
          glowColor: "#EF4444", // Red
          eyeContent: (
            <g fill="#EF4444">
              <circle cx="85" cy="115" r="10" />
              <circle cx="155" cy="120" r="6" />
            </g>
          ),
          mouthContent: <path d="M105 150 Q120 140 135 150" stroke="#EF4444" strokeWidth="4" strokeLinecap="round" fill="none" />,
        };
      case "idle":
      default:
        return {
          label: "Hi! I'm NUSTBot 🤖",
          glowColor: "#00D2FF", // Cyan Accent
          eyeContent: (
            <g fill="#00D2FF" className="robot-blink">
              <rect x="75" y="105" width="18" height="24" rx="8" />
              <rect x="145" y="105" width="18" height="24" rx="8" />
            </g>
          ),
          mouthContent: <rect x="105" y="145" width="30" height="6" rx="3" fill="#00D2FF" />,
        };
    }
  }, [state]);

  return (
    <div className="flex flex-col items-center justify-center p-8 h-full w-full relative z-10">
      
      {/* Dynamic Background Glow behind the mascot */}
      <div
        className="absolute inset-0 rounded-full blur-[80px] opacity-20 transition-colors duration-1000"
        style={{ backgroundColor: config.glowColor, transform: 'scale(0.8)' }}
      />

      <div className="mb-8 text-center relative z-20">
        <h2 className="text-4xl font-extrabold tracking-tight drop-shadow-md" style={{ color: "var(--nust-primary)" }}>
          NUST<span style={{ color: "var(--nust-accent)" }}>Bot</span>
        </h2>
        <p className="text-xs mt-1 uppercase tracking-widest font-semibold" style={{ color: "var(--text-secondary)" }}>
          Admissions Intelligence
        </p>
      </div>

      {/* Highly detailed SVG Mascot Container */}
      <div className="relative w-64 h-72 robot-float">
        <svg viewBox="0 0 240 280" className="w-full h-full drop-shadow-2xl">
          <defs>
            {/* Gradients to make the metal look shiny and premium */}
            <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#FFFFFF" />
              <stop offset="100%" stopColor="#E2E8F0" />
            </linearGradient>
            
            <linearGradient id="bodyGradDark" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#334155" />
              <stop offset="100%" stopColor="#0F172A" />
            </linearGradient>

            <linearGradient id="screenGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#020617" />
              <stop offset="100%" stopColor="#0F172A" />
            </linearGradient>

            <linearGradient id="armGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#CBD5E1" />
              <stop offset="100%" stopColor="#94A3B8" />
            </linearGradient>

            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* === Antenna === */}
          <g className="antenna">
            <rect x="117" y="10" width="6" height="30" rx="3" fill="url(#armGrad)" />
            <circle 
              cx="120" 
              cy="10" 
              r="10" 
              fill={config.glowColor} 
              filter="url(#glow)" 
              className="antenna-pulse" 
            />
          </g>

          {/* === Left Arm (Floating/Swaying) === */}
          <g className="robot-arm-l" style={{ transformOrigin: "40px 140px" }}>
            {/* Shoulder Joint */}
            <circle cx="35" cy="140" r="15" fill="var(--nust-primary)" />
            <circle cx="35" cy="140" r="10" fill="#0F172A" />
            {/* Arm Body */}
            <rect x="23" y="150" width="24" height="60" rx="12" fill="url(#armGrad)" className="dark:fill-[url(#bodyGradDark)]" />
            {/* Hand / Claw */}
            <path d="M 23 200 C 15 210, 15 225, 23 230 C 28 233, 35 233, 35 233 C 35 233, 32 225, 30 215 C 32 205, 35 197, 35 197 C 35 197, 28 197, 23 200 Z" fill="var(--nust-primary)" />
            <path d="M 47 200 C 55 210, 55 225, 47 230 C 42 233, 35 233, 35 233 C 35 233, 38 225, 40 215 C 38 205, 35 197, 35 197 C 35 197, 42 197, 47 200 Z" fill="var(--nust-primary)" />
          </g>

          {/* === Right Arm (Floating/Swaying) === */}
          <g className="robot-arm-r" style={{ transformOrigin: "200px 140px" }}>
            {/* Shoulder Joint */}
            <circle cx="205" cy="140" r="15" fill="var(--nust-primary)" />
            <circle cx="205" cy="140" r="10" fill="#0F172A" />
            {/* Arm Body */}
            <rect x="193" y="150" width="24" height="60" rx="12" fill="url(#armGrad)" className="dark:fill-[url(#bodyGradDark)]" />
            {/* Hand / Claw */}
            <path d="M 193 200 C 185 210, 185 225, 193 230 C 198 233, 205 233, 205 233 C 205 233, 202 225, 200 215 C 202 205, 205 197, 205 197 C 205 197, 198 197, 193 200 Z" fill="var(--nust-primary)" />
            <path d="M 217 200 C 225 210, 225 225, 217 230 C 212 233, 205 233, 205 233 C 205 233, 208 225, 210 215 C 208 205, 205 197, 205 197 C 205 197, 212 197, 217 200 Z" fill="var(--nust-primary)" />
          </g>

          {/* === Main Body / Head Container === */}
          <g className="body-group">
            {/* Main Rounded Shell */}
            <rect x="40" y="40" width="160" height="150" rx="50" fill="url(#bodyGrad)" className="dark:fill-[url(#bodyGradDark)]" stroke="var(--nust-primary)" strokeWidth="4" />
            
            {/* Ear Hubs */}
            <rect x="30" y="90" width="15" height="40" rx="5" fill="var(--nust-secondary)" />
            <rect x="195" y="90" width="15" height="40" rx="5" fill="var(--nust-secondary)" />

            {/* Face Screen (The Dark Visor) */}
            <rect x="55" y="75" width="130" height="90" rx="30" fill="url(#screenGrad)" stroke="#334155" strokeWidth="2" />
            
            {/* Screen Inner Reflection / Gloss */}
            <path d="M 60 100 Q 120 70 180 100 L 180 85 Q 120 70 60 85 Z" fill="#FFFFFF" fillOpacity="0.05" />

            {/* === Face Content (Eyes & Mouth) injected based on state === */}
            <g style={{ transition: 'all 0.4s ease-in-out' }} filter="url(#glow)">
              {config.eyeContent}
              {config.mouthContent}
            </g>
          </g>
        </svg>

        {/* Dynamic Shadow below the floating robot */}
        <div className="absolute -bottom-8 left-1/2 transform -translate-x-1/2 w-40 h-6 bg-black/10 dark:bg-black/30 rounded-[100%] blur-md" style={{ animation: "pulse 4s ease-in-out infinite" }} />
      </div>

      {/* Status Label (Glass Pill) */}
      <div
        className="glass-pill px-8 py-3 text-sm font-bold text-center mt-6 transition-all duration-300 z-20"
        style={{ color: "var(--text-primary)" }}
      >
        <div className="flex items-center justify-center gap-2">
          {state === "thinking" && <div className="w-2 h-2 rounded-full animate-ping" style={{ backgroundColor: config.glowColor }} />}
          {config.label}
        </div>
      </div>
    </div>
  );
}
