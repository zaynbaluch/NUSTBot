"use client";
import { useState, useEffect, useCallback } from "react";
import RobotMascot from "@/components/RobotMascot";
import Sidebar from "@/components/Sidebar";
import ChatPanel from "@/components/ChatPanel";
import ChatInput from "@/components/ChatInput";
import { useChat } from "@/hooks/useChat";
import { useSpeechToText } from "@/hooks/useSpeechToText";
import {
  loadConversations,
  saveConversation,
  deleteConversation,
  generateId,
} from "@/lib/chatStorage";

export default function Home() {
  const {
    messages,
    isLoading,
    robotState,
    status,
    sendMessage,
    stopGeneration,
    clearMessages,
    loadMessages,
  } = useChat();

  const speechToText = useSpeechToText();

  const [conversations, setConversations] = useState([]);
  const [activeConvoId, setActiveConvoId] = useState(null);

  // Load conversations from localStorage on mount
  useEffect(() => {
    setConversations(loadConversations());
  }, []);

  // Save conversation when messages change
  useEffect(() => {
    if (messages.length > 0 && activeConvoId) {
      const title =
        messages[0]?.content?.slice(0, 40) +
        (messages[0]?.content?.length > 40 ? "..." : "") ||
        "New Chat";
      const convo = {
        id: activeConvoId,
        title,
        messages,
        updatedAt: Date.now(),
      };
      saveConversation(convo);
      setConversations(loadConversations());
    }
  }, [messages, activeConvoId]);

  const handleSend = useCallback(
    (text) => {
      if (!activeConvoId) {
        const newId = generateId();
        setActiveConvoId(newId);
      }
      sendMessage(text);
    },
    [activeConvoId, sendMessage]
  );

  // When sending first message without active convo, set id
  useEffect(() => {
    if (messages.length === 1 && !activeConvoId) {
      setActiveConvoId(generateId());
    }
  }, [messages, activeConvoId]);

  const handleNewChat = useCallback(() => {
    setActiveConvoId(null);
    clearMessages();
  }, [clearMessages]);

  const handleSelectConvo = useCallback(
    (id) => {
      const convo = conversations.find((c) => c.id === id);
      if (convo) {
        setActiveConvoId(id);
        loadMessages(convo.messages);
      }
    },
    [conversations, loadMessages]
  );

  const handleDeleteConvo = useCallback(
    (id) => {
      deleteConversation(id);
      setConversations(loadConversations());
      if (activeConvoId === id) {
        setActiveConvoId(null);
        clearMessages();
      }
    },
    [activeConvoId, clearMessages]
  );

  return (
    <main className="flex h-screen w-full overflow-hidden bg-transparent">
      {/* ── 1. Extreme Left Sidebar ── */}
      <div className="flex-shrink-0 z-30 h-full">
        <Sidebar
          conversations={conversations}
          activeId={activeConvoId}
          onSelect={handleSelectConvo}
          onNew={handleNewChat}
          onDelete={handleDeleteConvo}
        />
      </div>

      {/* ── Main Content Area ── */}
      <div className="flex flex-1 flex-row min-w-0 h-full relative z-10">
        {/* ── 2. Mascot Column (Floating over gradient) ── */}
        <div className="hidden lg:flex flex-col items-center justify-center flex-shrink-0 h-full w-[450px]">
          <RobotMascot state={robotState} />
        </div>

        {/* ── 3. Chat Area Box (Glassmorphism pane) ── */}
        <div className="flex flex-col flex-1 min-w-0 h-full p-2 md:p-6 pl-0">
          <div className="glass-panel w-full h-full rounded-2xl md:rounded-[2.5rem] flex flex-col overflow-hidden shadow-2xl relative">
            
            {/* Ambient inner glow for the chat pane */}
            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-[var(--nust-glow)] to-transparent opacity-10 pointer-events-none" />

            <ChatPanel
              messages={messages}
              isLoading={isLoading}
              status={status}
              onSend={handleSend}
            />
            <div className="px-4 pb-4 pt-2 relative z-10">
              <ChatInput
                onSend={handleSend}
                isLoading={isLoading}
                onStop={stopGeneration}
                speechToText={speechToText}
              />
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
